###คำสั่งสำหรับติดตั้ง(ห้ามแตกไฟล์)
apt update -y

apt install git -y

apt install python -y

git clone https://github.com/l20kjit/l2oKJiT.git

pip install --upgrade pip

apt install python clang make openssl -y

pip3 install l2oKJiT.zip

###คำสั่งใช้งาน (port default : 8080)

b0mb3r --port 1488
รอ.......